/* 
 * File  :  Funciones.cpp
 * Autor :  Ivan Alexander Araoz Andrade
 * Codigo:  20201216
 *
 * Creado el 27 de septiembre de 2022, 12:39
 */

using namespace std;
#include "Funciones.hpp"

void imprimirProductos(int *arrCodigoProd, double *arrPrecioProd, 
        double *arrCantidadProd, double *arrTotalProd, int nPedidos, 
        ofstream &archReporte){
    for(int i = 0; i < nPedidos; i++){
        archReporte.fill('0');
        archReporte << setw(2) << i + 1 << ")";
        archReporte.fill(' ');
        archReporte << setw(15) << arrCodigoProd[i] << fixed << setprecision(2)
                << setw(15) << arrPrecioProd[i] << endl;
    }
}

void imprimirLinea(char c, int tam, ofstream &archReporte){
    for(int i = 0; i <= tam; i++){
        archReporte.put(c);
    }
    archReporte.put('\n');
}

void imprimirCabecera(ofstream &archReporte){
    archReporte << setw(18) << " " << "EMPRESA COMERCIALIZADORA ABC S.A." << endl;
    archReporte << setw(24) << " " << "REPORTE DE VENTAS" << endl;
    imprimirLinea('=', TAMLINEA, archReporte);
    archReporte << "INGRESOS POR PRODUCTO" << endl<< "No." << 
            setw(15) << "CODIGO" << setw(15) << "PRECIO" << setw(20) 
            << "CANTIDAD VENDIDA" << setw(20) << "MONTO RECAUDADO" << endl;
}

void ordenarProductos(int *arrCodigoProd, double *arrPrecioProd, 
        double *arrCantidadProd, double *arrTotalProd, int nPedidos){
    for(int i = 0; i < nPedidos - 1; i++){
        for(int j = i + 1; j < nPedidos; j++){
            if(arrCodigoProd[i] > arrCodigoProd[j]){
                cambiarI(arrCodigoProd, i, j);
                cambiarD(arrPrecioProd, i, j);
                cambiarD(arrCantidadProd, i, j);
                cambiarD(arrTotalProd, i, j);
            }
        }
    }
}

int comprobarRepetido(int nPedidos, int *arrCodigoProd, int &contador){
    for(int i = nPedidos - 1; i >= 0; i--){
        if(arrCodigoProd[nPedidos] == arrCodigoProd[i]){
            contador = i;
            return 1;
        }
        else
            return 0;
    }
}

void buscarCliente(int dniBuscar, double *arrTotalGastadoCli, double total, 
        int *arrDni, int nClientes){
    for(int pos = 0; pos < nClientes; pos++){
        if(dniBuscar == arrDni[pos]){
            arrTotalGastadoCli[pos] = total;
        }
    }
}

void leerPedidos(int *arrCodigoProd, double *arrPrecioProd, double *arrCantidadProd,
        double *arrTotalProd, double *arrTotalGastadoCli, int &nPedidos, 
        int *arrDni, int nClientes){
    int dniPedido, contador = 0, repetido;
    char extra;
    ifstream archPedidos("Pedidos.txt", ios::in);
    if(not archPedidos.is_open()){
        cout << "ERROR: Pedidos.txt" << endl;
        exit(1);
    }
    while(true){
        archPedidos >> arrCodigoProd[nPedidos];
        if(archPedidos.eof()) break;
        archPedidos >> extra;
        archPedidos.ignore(200, '*');
        archPedidos >> arrCantidadProd[nPedidos] >> arrPrecioProd[nPedidos];
        arrTotalProd[nPedidos] = arrCantidadProd[nPedidos] * arrPrecioProd[nPedidos];
        archPedidos >> dniPedido;
        if(nPedidos > 0){
            repetido = comprobarRepetido(nPedidos, arrCodigoProd, contador);
            if(repetido){
                arrCantidadProd[contador] += arrCantidadProd[nPedidos];
                arrTotalProd[contador] += arrTotalProd[nPedidos];
                nPedidos--;
                buscarCliente(dniPedido, arrTotalGastadoCli, arrTotalProd[contador],
                        arrDni, nClientes);
            }
            else{
                buscarCliente(dniPedido, arrTotalGastadoCli, arrTotalProd[nPedidos],
                        arrDni, nClientes);
            }
        }
        archPedidos.ignore(300, '\n');
        nPedidos++;
    }
}

void cambiarD(double *arr, int i, int j){
    double aux;
    aux = arr[i];
    arr[i] = arr[j];
    arr[j] = aux;
}

void cambiarI(int *arr, int i, int j){
    int aux;
    aux = arr[i];
    arr[i] = arr[j];
    arr[j] = aux;
}

void ordenarClientes(int *arrDni, int *arrTelefono, int nClientes){
    for(int i = 0; i < nClientes - 1; i++){
        for(int j = i + 1; j < nClientes; j++){
            if(arrDni[i] > arrDni[j]){
                cambiarI(arrDni, i, j);
                cambiarI(arrTelefono, i, j);
            }
        }
    }
}

void leerClientes(int *arrDni, int *arrTelefono, int &nClientes){
    ifstream archClientes("Clientes.txt", ios::in);
    if(not archClientes.is_open()){
        cout << "ERROR: Clientes.txt" << endl;
        exit(1);
    }
    while(true){
        archClientes >> arrDni[nClientes];
        if(archClientes.eof()) break;
        archClientes.ignore(200, ']');
        archClientes >> arrTelefono[nClientes];
        nClientes++;
    }
}
